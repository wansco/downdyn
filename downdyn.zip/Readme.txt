          DOWNHOLE DYNAMOMETER DATABASE INSTALLATION

                     (revised 5/28/98)

The Downhole Dynamometer Database consists of the data
browsing/viewing program, DownDyn, and the downhole dynamometer
data.  The Database is distributed on CD-ROM to ensure the
integrity of the data and to make distribution of the 40+ MBytes
of data easier.  DownDyn is compressed on the CD-ROM and must be
installed on your hard drive by running setup.exe.  The data is
not compressed and so is accessed by DOS or Windows file access
procedures directly from the CD-ROM to minimize the amount of 
available hard drive space required.

Graphics modules version:
The graphics server employs 4 modules:  graphx.vbx, gswag16.dll, 
gswdll16.dll, & gsw16.exe.  These all must be the same version.  
Current distribution version number is 4.50.  The version number 
can be determined by looking at the time property of the files.  
The setup program installs these files in the system directory.  
Upgrading of other software that uses some but not all of the 
same graphics modules can result in the version mismatch and 
failure of the program to run properly.   

Data Files:
The CD-ROM contains all the data collected from the downhole
dynamometer tools during these tests, including the raw data as
a-d counts and the processed data in engineering units.  The data
is organized according to test, with each test in its own 
subdirectories, well_1, well_2, well_3, etc.  Each subdirectory 
contains a descr*.txt file, the *.csv and *.dat data files, and 
the *.raw data files in their own subdirectory.  The names of the
subdirectories must not be changed.  

The file downdyn.ini is a catalogue of the tests performed on
each well and is used by the DownDyn to locate the files for
each test.  Currently the database contains the following
wells:

   RMOTC              May 1995 (well_1)
   Fiberglass         Oct 1995 (well_2)
   Rotaflex           Feb 1996 (well_3)
   Speed Change       Mar 1996 (well_4)
   Gas Separator (a)  Jul 1996 (well_5a)
   Gas Separator (b)  Jul 1996 (well_5b)
   Tension Pump       Dec 1996 (well_6)

(Test 5 is separated into parts a and b because different tool
locations were used in the two parts of the test.)
   
The file descr.txt contains a description of the well, rods 
string, tool placements, and failure history for each well.

The naming convention for the data files is as follows: 

               #x#a##.ext

where the,
  first number (#) is the tool number or "s" for surface 
    dynamometer data,
  letter (x) is a fixed character,
  second number (#) is the well number,
  letter (a) tells the day of the test,
  last number (##) is the test number on that day, and
  ext is an extension identifying the type of data file.
   
The *.csv files are comma delimited ASCII downhole dynamometer 
  data.
The *.dat files are surface dynamometer data in NABLA's format.
The *.dyn files are surface dynamometer data in Theta 
  Enterprises' RodDiag format.
The *.raw files are raw downhole dynamometer data in raw a-d 
  count units.

The raw data files contain columns of data including the following 
information:
Axial acceleration, Lateral acceleration #1, Lateral acceleration #2, 
Load #1, Load #2, Load #3, Pressure, and Temperature.  Units are A/D 
Counts.  To convert from A/D to engineering units, one needs the gain 
and offset.  The gain is determined by calibration and offset from 
tool response under known conditions, i.e., before the tool is run 
into the hole.  To obtain the necessary information to convert raw 
data to engineering units one should contact Albert Engineering.

The subdirectories RAWDATA contain all the raw data collected.  Only 
a subset of that data has been processed and in cataloged in the 
Well_@ directories.
   
To add your downhole data to your database:
1)  Add a subdirectory for your data named "Well_@" where @ is an
unused well number.  
2)  Copy / edit the following description, tools and file 
information to the downdyn.ini file replacing "@" with the 
unused well number.  
3)  The file name must conform to the naming convention described above. 
4)  In the "well_@" files registration, the "60" is the duration 
of the data in seconds of data and the "50" is the frequency at 
which data was taken in hertz.  (These parameters are used to 
determine the default start time, plot duration and amount of 
data; thus they are helpful but not critical.)
5)  It is important that the position of each field is not 
changed from that shown below.  That is, the first comma must be 
in position 65 and the "x" must be in position 114, etc.  
6)  Edit MaxFiles=?? to be at least as large the largest File#?? 
entry under [Well_@ Files].  In the example below, it would be 
MaxFiles=2.
7)  A comment field, from positions 49->64 can be used to record 
a brief descriptive text to help identify the file.

[Well_@ Description]
Description=Your Well Name

[Well_@ MaxFiles]
MaxFiles=??

[Well_@ Tools]
Tool#1=Tool#1 - Location your tool 1
Tool#2=Tool#2 - Location your tool 2
Tool#3=Tool#3 - Location your tool 3 
Tool#4=Tool#4 - Location your tool 4
Tool#5=Tool#5 - Location your tool 5

[Well_@ Files]
File#01=??/??/9? ??:??:00 AM   60     50   228k                 , 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,   x????.csv
File#02=??/??/9? ??:??:00 AM  Surface Dyno   0k                 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   x????.dat

                                                                                                   1         1         1
         1         2         3         4         5         6         7         8         9         0         1         2 
12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012

(Sample input and position count will line up if these lines are not wrapped.)

****************************************************************
INSTALLATION PROBLEMS

Due to unforeseen differences in operating systems, the setup on the 
CD may not find the file vbrun300.dll.  If that file is already on 
your system no error is generated; if it is not, the setup aborts.  
The disk supplied with version 1.2 fixes this problem.  


Principal investigator:	
  John Waggoner		
Programmer:		
  A.J. (Chip) Mansure	ajmansu@sandia.gov  505-844-9315
Technical contact:	
  Robert Cutler		rpcutle@sandia.gov  505-844-5576

Sandia National Laboratories  
P.O. Box 5800, MS 0705 
Albuquerque, NM 87185-0705




